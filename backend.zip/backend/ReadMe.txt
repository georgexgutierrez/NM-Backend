3 users
admin/admin
user1/password
user2/password

Development Enviroment
Eclipse Neon - Hibernate Plugin, Subversion plugin, Glassfish plugin

Source Control
Subversion - have it running on a server in my house

Technologies used
UI - protoype,jsp
ServerSide - JaaS for security(jdbc realm), hibernate(entity bean generation), Jersey(Rest jax-rs), JDBC(stored procedures)
Server - Glassfish 4.0
Database - MySql

Extras done
sharing of checklists with other users

